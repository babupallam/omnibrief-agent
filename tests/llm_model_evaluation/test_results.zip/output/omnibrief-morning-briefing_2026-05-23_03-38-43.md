# Morning Briefing

Generated on: 2026-05-23 03:38:43
Run ID: `omnibrief-morning-briefing_2026-05-23_03-38-43`
Trace folder: [omnibrief-morning-briefing_2026-05-23_03-38-43](../traces/omnibrief-morning-briefing_2026-05-23_03-38-43)

## Morning Briefing Executive Summary

No successful extractions were available to summarize.

## 1. Wikipedia Current Events

Source: [https://en.wikipedia.org/wiki/Portal:Current_events](https://en.wikipedia.org/wiki/Portal:Current_events)

Status: `failure`

Trace file: [trace_wikipedia-current-events_2026-05-23_03-44-36.json](../traces/omnibrief-morning-briefing_2026-05-23_03-38-43/trace_wikipedia-current-events_2026-05-23_03-44-36.json)

Extraction failed.

🔗 Navigated to https://en.wikipedia.org/wiki/Portal:Current_events

## 2. Hacker News

Source: [https://news.ycombinator.com/](https://news.ycombinator.com/)

Status: `failure`

Trace file: [trace_hacker-news_2026-05-23_03-44-36.json](../traces/omnibrief-morning-briefing_2026-05-23_03-38-43/trace_hacker-news_2026-05-23_03-44-36.json)

Extraction failed.

🔗 Navigated to https://news.ycombinator.com/

## 3. BBC Weather London

Source: [https://www.bbc.com/weather/2643743](https://www.bbc.com/weather/2643743)

Status: `failure`

Trace file: [trace_bbc-weather-london_2026-05-23_03-44-05.json](../traces/omnibrief-morning-briefing_2026-05-23_03-38-43/trace_bbc-weather-london_2026-05-23_03-44-05.json)

Extraction failed.

🔗 Navigated to https://www.bbc.com/weather/2643743
Waited for 5 seconds

## Telemetry & Costs

- Total prompt tokens: 6907
- Total completion tokens: 650
- Total combined tokens: 7557
- Total execution time: 352.584 seconds
